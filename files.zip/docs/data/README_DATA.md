# PSI_YÉKIT Dataset v1.0 — Data for Bioterritorial Instability in Jequitinhonha

> **"Data is not neutral. This dataset is a weapon against hydro-colonial erasure."**

**Status:** Ready for Zenodo deposit  
**Temporal coverage:** 2015–2024 (monthly)  
**Spatial unit:** Municipality (IBGE code, Jequitinhonha Valley)  

---

## 1. What this dataset is

This directory documents the **public-facing dataset** associated with the $\Psi_{Yékit}$ / ΨJeq model:

- Monthly **H-E-V-L predictors**:
  - **H** — hydro-climatic hazards (drought, heat)
  - **E** — exposure (demand vs. water availability, people at risk)
  - **V** — vulnerability (institutional friction, regulatory capture)
  - **L** — upstream silviculture and land-use memory
- Observed **systemic failures** \(Y\) (water rupture / sanitary saturation)
- Bayesian posterior estimates for the **latent instability state** \(Ψ\) and failure probability \(p_{failure}\)

Everything is **aggregated at municipal level** and anonymized to satisfy **LGPD** and **k-anonymity (k ≥ 5)**.

---

## 2. File structure

```text
data/
├── psi_yekit_inputs_monthly_long.csv      # H, E, V, L (tidy long, month × municipality × variable)
├── psi_yekit_labels_monthly.csv           # Y_failure and failure_type (observed)
├── psi_yekit_posteriors_monthly.csv       # Ψ posteriors + p_failure + versioning
├── units_metadata.csv                     # Municipal-level metadata (no geometry)
├── sources_metadata.csv                   # Provenance, licenses, processing scripts
└── DATA_DICTIONARY.csv                    # Machine-readable data dictionary
```

Companion docs (this folder):

- `ANONYMIZATION.md` — LGPD protocol, k-anonymity guarantees
- `PROVENANCE.md` — who/what/where of each variable (H, E, V, L)

---

## 3. Spatial & temporal units

- **Time (`time`)**:  
  - String `YYYY-MM`, representing the **first day of the month** (ISO-8601 internally).
  - Temporal resolution: **monthly**.

- **Space (`unit_id`)**:  
  - Format: `BR-MG-IBGE-XXXXXX` (6-digit IBGE municipal code, prefixed by country/state).
  - No coordinates, no geometries, no bairros — just a stable key you can merge with official IBGE meshes.

See `units_metadata.csv` for:

- `unit_id`, `unit_type` (= `municipio`), `name`, `ibge_code`, `area_km2`, `region` (`Alto|Médio|Baixo` Jequitinhonha).

---

## 4. Core tables

### 4.1 `psi_yekit_inputs_monthly_long.csv` — H-E-V-L predictors

**Shape:** one row per (`time`, `unit_id`, `variable`).

Columns:

- `time` — `YYYY-MM`
- `unit_id` — `BR-MG-IBGE-XXXXXX`
- `variable` — variable name (controlled vocabulary: `H_*`, `E_*`, `V_*`, `L_*`)
- `value` — numeric value (standardized where applicable)
- `unit` — measurement unit (`SD`, `°C`, `index`, `proportion`, etc.)
- `quality_flag` — see Section 5
- `source_key` — foreign key → `sources_metadata.csv`

Example:

```csv
time,unit_id,variable,value,unit,quality_flag,source_key
2015-01,BR-MG-IBGE-310010,H_spei_12m,-0.45,SD,OK,cmip6_ensemble
2015-01,BR-MG-IBGE-310010,H_tmax_anom,1.2,°C,OK,cmip6_ensemble
2015-01,BR-MG-IBGE-310010,E_demand_ratio,0.32,index,OK,ana_regla
2015-01,BR-MG-IBGE-310010,V_recharge_ratio,1.15,index,OK,literatura_hidrogeol
2015-01,BR-MG-IBGE-310010,L_silviculture_std,0.78,SD,OK,mapbiomas_col9
```

### 4.2 `psi_yekit_labels_monthly.csv` — observed systemic failure

Binary outcome + classification of the type of failure.

Columns:

- `time` — `YYYY-MM`
- `unit_id` — municipality
- `Y_failure` — `{0,1}` (0 = no systemic failure; 1 = failure)
- `failure_type` — `{hydric|sanitary|both|none}`
- `quality_flag` — `{OK|SUPPRESSED_LGPD_K<5}`

Operational rule for `Y_failure = 1`:

1. **Water Rupture**: river flow < Q7,10 for ≥ 7 consecutive days; OR  
2. **Sanitary Saturation**: respiratory admissions (CID-J) > μ + 2σ (historical baseline).

Example:

```csv
time,unit_id,Y_failure,failure_type,quality_flag
2015-01,BR-MG-IBGE-310010,0,none,OK
2015-02,BR-MG-IBGE-310010,0,none,OK
2015-03,BR-MG-IBGE-310010,0,none,OK
2023-02,BR-MG-IBGE-310010,1,hydric,OK
2023-05,BR-MG-IBGE-310010,1,sanitary,OK
```

### 4.3 `psi_yekit_posteriors_monthly.csv` — latent state (Ψ) & p_failure

This is the **bridge** between Bayesian code and policy dialog.

Columns:

- `time`, `unit_id` — keys
- `psi_median` — posterior median of latent instability state Ψ
- `psi_q025`, `psi_q975` — 95% credible interval bounds
- `p_failure` — estimated systemic failure probability, \(P(Y=1 \mid Ψ)\)
- `model_version` — e.g. `v4.0`
- `software_doi` — Zenodo DOI of the software
- `run_commit` — Git SHA-1 of the code that produced these estimates

Example:

```csv
time,unit_id,psi_median,psi_q025,psi_q975,p_failure,model_version,software_doi,run_commit
2015-01,BR-MG-IBGE-310010,0.85,0.62,1.14,0.12,v4.0,10.5281/zenodo.XXXXXX,abc123def456...
2015-02,BR-MG-IBGE-310010,0.91,0.67,1.22,0.14,v4.0,10.5281/zenodo.XXXXXX,abc123def456...
2023-02,BR-MG-IBGE-310010,1.82,1.43,2.24,0.23,v4.0,10.5281/zenodo.XXXXXX,abc123def456...
```

> **Warning — do not fetishize Ψ:**  
> Ψ is a **latent Bayesian state**, not a directly observed variable. These are summaries of a posterior distribution, conditional on data, priors, and model structure. Misusing Ψ as an “objective scalar of truth” is epistemic violence.

---

## 5. Missing data & `quality_flag`

We never hide missingness. Instead we:

- Use `NA` for missing numeric values, and
- Tag the **reason** in `quality_flag`.

### 5.1 Inputs (`psi_yekit_inputs_monthly_long.csv`)

- `OK` — complete and validated
- `MISSING_SOURCE` — not available in primary source
- `IMPUTED_INTERPOLATION` — linearly interpolated in time
- `IMPUTED_REGRESSION` — model-based imputation

### 5.2 Labels (`psi_yekit_labels_monthly.csv`)

- `OK` — cell published, k ≥ 5
- `SUPPRESSED_LGPD_K<5` — suppressed cell to enforce k-anonymity

---

## 6. Anonymization, LGPD & k-anonymity

Full details in [`ANONYMIZATION.md`](ANONYMIZATION.md). In short:

1. **Space:** municipality-level only (no bairros, no points).  
2. **Time:** monthly aggregation for health-sensitive signals.  
3. **Suppression:** any cell with underlying counts < 5 is masked and flagged.  
4. **No PII:** no names, CPFs, addresses, or quasi-IDs at individual level.  
5. **Audit script:** `scripts/06_verify_kanonymity.R` checks k ≥ 5 before release.

You are invited to **audit** these guarantees before reusing the data, especially if you plan to blend with other sensitive datasets.

---

## 7. Provenance: where each bit comes from

Machine-readable:

- `sources_metadata.csv` — one row per source or pipeline, with:
  - `source_key`, `variable_pattern`, `source_name`, `source_version`,
  - `access_date`, `license`, `url`, `citation`, `processing_script`.

Narrative (human):

- [`PROVENANCE.md`](PROVENANCE.md) — detailed story behind:
  - `H_spei_12m`, `H_tmax_anom`, `H_heat_days`
  - `E_demand_ratio`, `E_population_10km`, `E_exposure_index`
  - `V_recharge_ratio`, `V_institution_friction`, `V_vulnerability_index`
  - `L_silviculture_raw`, `L_silviculture_ema`, `L_silviculture_std`

If your work depends critically on a single variable, **read its provenance** before drawing strong conclusions.

---

## 8. How to (re)use the dataset

### 8.1 Reproducing the Ψ model

In R:

```r
# 1) load data
inputs   <- readr::read_csv("data/psi_yekit_inputs_monthly_long.csv")
labels   <- readr::read_csv("data/psi_yekit_labels_monthly.csv")
post     <- readr::read_csv("data/psi_yekit_posteriors_monthly.csv")

# 2) join or reshape as needed to feed Stan
# (see scripts/01_preprocess_data.R and scripts/02_fit_model.R)
```

### 8.2 Scenario analysis / communication

- Use `psi_yekit_posteriors_monthly.csv`:
  - map **Ψ** trajectories over time,
  - highlight months where **p_failure** crosses your risk threshold.
- Combine with your own territorial layers by merging on `ibge_code` or `unit_id`.

---

## 9. Licensing & citation

This dataset follows the **artifact-based licensing** of the repo:

- **Data (`data/`)**: **CC0 1.0** (Public Domain Dedication)  
  You can reuse, modify, and redistribute without legal attribution requirements.  
  Ethically, please still cite and name the valley.

- **Textual docs (this file, PDFs, narrative reports)**: **CC BY 4.0**  
  See main `README.md` for details and canonical citation text.

Canonical dataset citation:

```text
Yékit (2026). PSI_YÉKIT Dataset v1.0: Monthly hydroclimatic and territorial 
predictors for systemic risk in the Jequitinhonha Valley, Brazil (2015-2024). 
Zenodo. https://doi.org/10.5281/zenodo.DATASET_DOI_AQUI
```

Software citation: see `CITATION.cff` or the BibTeX block in the root `README.md`.

---

## 10. Contact & political intent

This dataset exists because **someone is trying to erase what it reveals**.

- **Portal:** https://modelo.yekit.org  
- **Issues:** https://github.com/jequitinhonha-analysis/psi-jeq-model/issues (tag `[dataset]`)  
- **Email:** info@yekit.org  

If you are:

- a **community organizer** — use this to negotiate, resist, litigate.
- a **researcher** — do not neutralize the politics; extend them with rigor.
- a **company** — any use that worsens territorial injustice is a form of data abuse.

```text
VEJE — Ver, Escutar, Jequitinhonha.
```