# PSI_YÉKIT Dataset 1.0 — Guia de uso

**Licença do dataset:** Creative Commons Attribution 4.0 International (CC BY 4.0)

Este diretório descreve a estrutura e as regras de publicação do dataset PSI_YÉKIT 1.0 (mensal, 2015–2024), agregado por município (código IBGE) para conformidade com LGPD.

## Estrutura

- `data/psi_yekit_inputs_monthly_long.csv`: preditores **H/E/V/L** em formato *tidy/long*.
- `data/psi_yekit_labels_monthly.csv`: desfecho observado `Y_failure` (0/1) e `failure_type`.
- `data/psi_yekit_posteriors_monthly.csv`: estimativas posteriores do estado latente `Ψ` e `p_failure`.
- `data/units_metadata.csv`: metadados públicos das unidades espaciais (municípios).
- `data/sources_metadata.csv`: fontes/licenças/citações por variável (via `source_key`).
- `data/DATA_DICTIONARY.csv`: dicionário de dados completo.

## Aviso obrigatório sobre Ψ (estado latente)

> **Ψ é uma variável latente inferida por método Bayesiano; estes valores representam resumo posterior (mediana e IC95%). Ψ não é dado observado, mas estimado pelo modelo PSI_YÉKIT 1.0 (DOI: XXX).**

## Qualidade e privacidade

- A coluna `quality_flag` existe para **todas** as células publicadas.
- Células suprimidas por LGPD (k-anonymity) devem ser marcadas como `SUPPRESSED_LGPD_K<5`.

Ver `ANONYMIZATION.md` para detalhes.

## Citação recomendada (placeholders)

### Dataset

Yékit (2026). **PSI_YÉKIT Dataset v1.0**: Monthly hydroclimatic and territorial predictors for systemic risk in the Jequitinhonha Valley, Brazil (2015–2024). Zenodo. https://doi.org/10.5281/zenodo.DATASET_DOI_AQUI

### Software

Yékit (2026). **PSI_YÉKIT**: Bayesian state-space model for bioterritorial instability assessment (Version 1.0) [Computer software]. Zenodo. https://doi.org/10.5281/zenodo.SOFTWARE_DOI_AQUI

## Como abrir os dados

Os arquivos são CSV (UTF-8). Exemplos:

### Python

```python
import pandas as pd
inputs = pd.read_csv('data/psi_yekit_inputs_monthly_long.csv')
labels = pd.read_csv('data/psi_yekit_labels_monthly.csv')
post = pd.read_csv('data/psi_yekit_posteriors_monthly.csv')
```

### R

```r
inputs <- read.csv('data/psi_yekit_inputs_monthly_long.csv')
labels <- read.csv('data/psi_yekit_labels_monthly.csv')
post   <- read.csv('data/psi_yekit_posteriors_monthly.csv')
```
