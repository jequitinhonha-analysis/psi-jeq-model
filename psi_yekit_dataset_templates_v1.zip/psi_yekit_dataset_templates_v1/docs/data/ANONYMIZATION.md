# PSI_YÉKIT Dataset 1.0 — Anonimização e LGPD

Este documento descreve o protocolo de anonimização para publicação do dataset PSI_YÉKIT 1.0.

## Objetivo

Garantir que os dados publicados:
- não contenham **PII** (identificadores diretos),
- estejam agregados o suficiente para evitar reidentificação,
- cumpram **k-anonymity com k≥5** para variáveis sensíveis (especialmente saúde).

## Regras de agregação

1) **Agregação espacial (canônica):** município (código IBGE)
- `unit_id` no formato `BR-MG-IBGE-XXXXXX`.
- Não publicar coordenadas, centróides ou geometrias.

2) **Agregação temporal (canônica):** mensal
- `time` no formato `YYYY-MM`.

## Supressão por k-anonymity (k≥5)

Para qualquer célula sensível (p.ex., contagens de eventos de saúde) em que a contagem subjacente seja <5, a publicação deve:
- suprimir o valor (usar `NA`), e
- marcar `quality_flag = SUPPRESSED_LGPD_K<5`.

## Vocabulário de `quality_flag`

- `OK`
- `MISSING_SOURCE`
- `IMPUTED_INTERPOLATION`
- `IMPUTED_REGRESSION`
- `SUPPRESSED_LGPD_K<5`

## Auditoria mínima antes do depósito

Checklist:
- [ ] varrer o dataset para garantir ausência de colunas com PII
- [ ] verificar k≥5 para variáveis sensíveis e aplicar supressão onde necessário
- [ ] registrar versões/commits de scripts de agregação/anonimização
- [ ] gerar checksums SHA-256 dos arquivos finais

## Script de verificação (esqueleto)

R (exemplo):

```r
# scripts/06_verify_kanonymity.R
verificar_kanonymity <- function(data, k = 5) {
  grupos <- aggregate(list(n=rep(1, nrow(data))), by=list(time=data$time, unit_id=data$unit_id), FUN=sum)
  violacoes <- subset(grupos, n < k)
  if (nrow(violacoes) > 0) {
    warning(paste('ATENÇÃO:', nrow(violacoes), 'células com k <', k))
    return(list(status='FALHA', violacoes=violacoes))
  }
  message(paste('✓ K-anonymity verificada: todas as células têm k ≥', k))
  return(list(status='OK', violacoes=NULL))
}
```
