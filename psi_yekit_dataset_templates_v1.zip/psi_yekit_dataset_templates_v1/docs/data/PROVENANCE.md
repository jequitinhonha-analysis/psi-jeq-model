# PSI_YÉKIT Dataset 1.0 — Proveniência e transformações

Este documento registra a rastreabilidade (proveniência) das variáveis publicadas.

## Convenções

- **H_***: perigos climáticos
- **E_***: exposição
- **V_***: vulnerabilidade
- **L_***: uso do solo a montante (silvicultura)
- **Y_***: observáveis do desfecho
- **Ψ**: estado latente inferido (arquivo separado)

## Vetor L (silvicultura a montante)

### Definição

`L_silviculture_raw` é um índice de pressão silvícola a montante, calculado como:

L_raw(t) = Σ_i (A_euc,i(t) × W_hydro,i × W_recarga,i) / A_total_upstream

Onde:
- A_euc,i(t): área de silvicultura na sub-bacia i no ano t (MapBiomas)
- W_hydro,i: peso de contribuição hidrológica da sub-bacia i para o ponto-alvo
- W_recarga,i: peso de importância de recarga (chapadas/veredas/zonas de recarga)

### Memória hidrológica (EMA)

`L_silviculture_ema` aplica média móvel exponencial:

L(t) = λ·L_raw(t) + (1-λ)·L(t-1), com λ=0.5 (padrão)

Condição inicial: L(1)=L_raw(1)

### Padronização

`L_silviculture_std` é o Z-score de `L_silviculture_ema`.

## Estado latente Ψ

`psi_median`, `psi_q025`, `psi_q975` são resumos posteriores do estado latente inferido pelo PSI_YÉKIT.

**Importante:** Ψ não é observável; é inferido pelo modelo e publicado para transparência/reprodutibilidade.

## Fontes e licenças

As fontes, versões e licenças são registradas em `data/sources_metadata.csv`.

Recomendação: preencher a coluna `citation` conforme a orientação oficial de cada provedor.
