# Ψ_Jeq — LaTeX sources (EN/ES)

This package contains LaTeX sources for:
- the complete technical specification of the Ψ_Jeq model (v3.2; 03 Jan 2026)
- Technical Note No. 01/2026 (risk characterization; 03 Jan 2026)

Folders:
- en/ : English sources
- es/ : Spanish sources

Compilation (pdfLaTeX):
    pdflatex model_spec_en.tex
    pdflatex tech_note_en.tex
    pdflatex model_spec_es.tex
    pdflatex tech_note_es.tex
